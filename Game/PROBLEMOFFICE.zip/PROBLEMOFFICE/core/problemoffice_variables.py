from core.problemoffice_colors import *
import pyttsx3
import os
import re
import cowsay
import time
import sys
import random
## tiempos de espera
timesl = 1
timesl2 = 0.3
timesl3 = 2
## Finales
end1 = False
end2 = False
end3 = False 
allends = False
debugMode = False

## Textos repetidos
command = RESET + "💾 Comando: " + LIMA
introT = MORADOCLARO +  " ╔══════════════════════════════════════╗\n ║           PROBLEMOFFICE v2.0         ║\n ╚══════════════════════════════════════╝"
introM = MORADOCLARO +  " ╔══════════════════════════════════════╗\n ║          TERMINAL JOB MANAGER        ║\n ╚══════════════════════════════════════╝"
introF = MORADOCLARO +  " ╔══════════════════════════════════════╗\n ║              LOS FINALES             ║\n ╚══════════════════════════════════════╝"