# 🎮 ProblemOffice

## Versión
2.0

## Desarrollador
Daniel Andrés Naranjo

## Lenguaje
Python 3.14

## Librerías
- colorama
- cowsay

## Descripción

ProblemOffice es un juego de terminal basado en decisiones.
El jugador deberá descubrir los secretos ocultos de una empresa
mientras toma decisiones que cambian el final del juego.

## Cómo ejecutar

```bash
py main.py
```

## Estado del proyecto

🟢 En desarrollo