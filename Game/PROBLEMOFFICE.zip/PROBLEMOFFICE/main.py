from game.problemoffice_introAdminmoment import nombre
from core.problemoffice_variables import *
init(autoreset=True)
print(introT)
a = True
while a:
    print("")
    play = input(LIMA + "🎮 Jugar 🎮 [1]\n" ## MENU DE INCIO
                + GRIS + "⚙ Configuraciones ⚙ [2] *desarrollo*\n"
                + CYANOSCURO + "🛠 Actualizaciones ✔ [3]\n" 
                + AMARILLOCLARO + "📋 ver creditos 📋 [4]\n"
                + AMARILLOSCURO + "⭐ Calificación ⭐ [5]\n\n" 
                + ROJOSCURO + "🔴 salir 🔴 [0]\n\n" 
                + RESET + command)

    if play == "1": ## JUEGO
        print("")        
        cowsay.kitty("que lo disfrutes ;)")
        time.sleep(timesl)
        input(ROJOCLARO +"\n🔴 encender equipo 🔴 [enter] ")
        os.system("cls")
        nombre()

    elif play == "4" : ## CREDITOS
        print(AZUL + "💻 Programador 💻:\n"
              + CYANCLARO +"Daniel Andrés Naranjo\n\n"
              + AZUL + "💿 Lenguaje 💿:\n"
              + CYANCLARO + "Python 3.14\n\n"
              + AZUL + "📚 Librerías 📚:\n"
              + CYANCLARO + "Colorama\nRandom\nsys\ntime\nre\nos\nCowsay\n\n"
              + AZUL + "🛠 Proyecto iniciado 🗓:\n"
              + CYANCLARO + "Junio\n" + LIMA + "2026")
    elif play == "5":
        print(AMARILLOCLARO + "----- ⭐ PONME UNA CALIFICACIÓN ⭐ -----")
        reseña = input("Reseña: ")
        print("--- Cuantas estrellas le darias? ---" + "\n [1-5 con decimales]")
        stars = input(command)
        print("GRACIAS POR TU COMENTARIO")
        with open("reviews.txt", "a", encoding="utf-8") as archivo:
            archivo.write("Reseña: " + reseña + f"\nEstrellas: {stars}")
    elif play == "0": ## SALIR
        print("")
        cowsay.tux("ADIOS")
        a = False

    elif play == "3": ## ACTUALIZACIONES
        print(AZUL + "Actualizaciones recientes\n"
              + CYANCLARO + "1.0v\n"
            + LIMA + "-Gameplay completo\n-Solucion de bug de la version beta\n\n"
              + AZUL + "2.0v\n"
              + LIMA + "-Finales nuevos \n-introducción nueva \n-colores de interfaz \n-pagina web descargable\n\n")
        
    elif (play == "2"): ## CONFIGURACIONES
        print(GRIS + "⚙ CONFIGURACIONES ⚙ :\n" +
              AMARILLOCLARO + "¡¡PROXIMAMENTE EN 3.0v!!")
#======================================================================================#
# ALERTA: ESTE ARCHIVO ES EL ENCARGADO DE EJECUTAR CORRECTAMENTE EL JUEGO, SI SE BORRA #
# NO VOLVERA A FUNCIONAR                                                               #
#======================================================================================#