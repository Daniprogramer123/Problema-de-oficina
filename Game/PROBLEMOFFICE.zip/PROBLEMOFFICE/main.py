from problemoffice_introAdminmoment import nombre
from problemoffice_variables import *
init(autoreset=True)
print(MORADOCLARO +  "╔══════════════════════════════════════╗\n"
                     "║          PROBLEMOFFICE v2.0          ║\n"
                     "╚══════════════════════════════════════╝")
a = True
while a:
    print("")
    play = input(LIMA + "🎮 Jugar 🎮 [1]\n" + GRIS + "⚙ Configuraciones ⚙ [2]\n"
                  + AMARILLOCLARO + "📋 ver creditos 📋[3]\n\n" + ROJOSCURO + "🔴 salir 🔴 [0]\n" + Fore.RESET)
    if play == "1":
        cowsay.kitty("que lo disfrutes ;)")
        time.sleep(timesl)
        input(ROJOCLARO +"🔴 encender equipo 🔴 [enter] ")
        nombre()
    elif play == "3":
        print(AZULOSCURO + "💻 Programador 💻:\n"
              + AZULCLARO +"Daniel Andrés Naranjo\n\n"
              + AZULOSCURO + "💿 Lenguaje 💿:\n"
              + AZULCLARO + "Python 3.14\n\n"
              + AZULOSCURO + "📚 Librerías 📚:\n"
              + AZULCLARO + "Colorama\n Cowsay\n\n"
              + AZULOSCURO + "🛠 Proyecto iniciado 🗓:"
              + AZULCLARO + "Junio\n2026")
    elif play == "0":
        cowsay.tux("ADIOSIIN")
        a = False
    elif (play == "2"):
        print(GRIS + "⚙ CONFIGURACIONES ⚙ :\n" +
              LIMA +"⚙ color de texto principal y del fondo 💻 [1]\n"  +
              Fore.RED +"🔴 Salir 🔴[0]")
        con = input("Comando: ")
        if con == "1":
            print(AZULOSCURO + "Color: X \n" + CYANCLARO + "X = Fondo")
            z =input("Comando:")
            os.system(f"color {z}7")
        elif con == "0":
            print(ROJOCLARO + "Configuracion no guardada")
#======================================================================================#
# ALERTA: ESTE ARCHIVO ES EL ENCARGADO DE EJECUTAR CORRECTAMENTE EL JUEGO, SI SE BORRA #
# NO VOLVERA A FUNCIONAR                                                               #
#======================================================================================#