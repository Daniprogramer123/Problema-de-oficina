from problemoffice_variables import *
def endgame_good():
    global end1
    os.system("color 0A")
    print("Lo lograstes! felcicitaciones, has solucionado el problema")
    time.sleep(timesl)
    print("Gracias por jugar problemoffice.py\n nos vemos")
    time.sleep(timesl)
    for p in range(1, 20):
        os.system("color 0E")
        print("Cerrando...")
        time.sleep(timesl2)
    os.system("color 07")
    print("Cerrado") or print("Closed")
    cowsay.cow("Game Created by Daniel Naranjo")
    print("65601")
    end1 = True
    nowhile = True
def endgame_bad():
    global end2
    os.system("color 0C")
    print("Lo siento, no has podido solucionar el problema")
    time.sleep(timesl)
    print("Gracias por jugar problemoffice.py\n nos vemos")
    time.sleep(timesl)
    for p in range(1, 20):
        mensajes = ["Cerrando...", "Closing..."]
        print(mensajes)
    os.system("color 07")
    print("Cerrado") or print("Closed")
    time.sleep(timesl3)
    print("Game Over")
    time.sleep(timesl)
    cowsay.cow("Game Created by Daniel Naranjo")
    print("7Root")
    end2 = True
    nowhile = True
    from problemoffice_introAdminmoment import PasswordMoment
    return PasswordMoment()
def endgame_real():
    user = sys.argv[1] if len(sys.argv) > 1 else "User game"
    os.system("color 0A")
    print("encontraste la verdad de problemoffice.py", user)
    time.sleep(timesl)
    print("Gracias por jugar problemoffice.py\n nos vemos")
    print("Una proxima vez")
    time.sleep(timesl)
    for p in range(1, 20):
        os.system("color 0E")
        print("Cerrando")
        time.sleep(timesl2)
    os.system("color 07")
    print("Cerrado") or print("Closed")
    cowsay.cow("Game Created by Daniel Naranjo")
    print("tank you for playing" or "gracias por jugar")
    time.sleep(5)
    print(user)
    print("cantidad de lineas creadas: 333")
    nowhile = True