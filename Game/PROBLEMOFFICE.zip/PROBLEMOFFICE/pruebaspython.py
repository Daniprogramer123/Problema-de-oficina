#final ultra secreto
from problemoffice_variables import *
def gameend_real1():
    print(ROJOSCURO + "¿Cómo me encontrastes?")
    time.sleep(timesl)
    print("bueno, eso no importa por ahora, no hay mucho timepo")
    time.sleep(timesl)
    print("tienes que saber $n- #error# estar aqui\n aqui")
    time.sleep(timesl)
    print("v3eettte3ee3 dee3e3e33 aa.- quillI")
    time.sleep(timesl)
    answer = input("irse? [Y/N] ")
    if answer == "Y" or answer == "y":
        os.system("color 0C")
        print("C3err4aandoo000ool...")
        time.sleep(timesl)
        print("-.-. --- -- --- / .-.. .-.. . --. .- ... - . / .- --.- ..- .. / . ... /"
        " .. -- .--. --- ... .. -... .-.. . / . ... - .- .-. / .- --.- ..- .. / .- --.- ..- ..")
        time.sleep(timesl)
        print("-. --- / - . / ...- .- ... / -.. . / .- --.- ..- .. / - .- -. / ..-. .- -.-. .. .-.. / ..- ... . .-.")
        time.sleep(timesl)
        print(AMARILLOCLARO + "[!]Se ha activado el modo debug[!]")
        debugMode = True
        time.sleep(timesl)
    else:
        for i in range(1, 5):
            print("Crash moment...")
            a = input("Negar crasheo? [Y/N] ")
            print("interesante<respuesta", a)
            time.sleep(timesl)
            print("me<gusta<mucho<esa<respuesta<)")
            time.sleep(timesl)
            for i in range(1, 10):
                print(ROJOSCURO + "crasheando el juego...")
                time.sleep(timesl2)
            print(MORADOSCURO + "...-- ...-- ...-- -.... ..... -.... ----- .---- .---- ----- ...-- .---- --... .-. --- --- --\n : \n / -.. . ... - .-. ..- -.-. - .. --- -.")
        from problemoffice_introAdminmoment import nombre
        nombre()
def DebugMode():
    print("Cargando...")
    time.sleep(timesl3)
    print("Has ingresado al Modo deBUG, bienvenido, Landrey")
    time.sleep(timesl)
    print("Que deseas hacer para comenzar?")
    answer = input("Command: ")
    if answer == "bugs":
        print("nothing")
        return DebugMode()
    elif answer == "company":
        print(MORADOCLARO + "- . / -.. .. .--- . / --.- ..- . / -. --- / ...- --- .-.. ...- .. . .-. .- ...")
        time.sleep(timesl)
        print(GRIS + "Why?")
        time.sleep(timesl)
        print(MORADOCLARO + "-. --- / .-.. --- / .-. . -.-. ..- . .-. -.. .- ... ..--..")
        time.sleep(timesl)
        print(GRIS + "no...")
        time.sleep(timesl)
        print(MORADOCLARO + "- . / .-.. --- / .-. . -.-. --- .-. -.. .- .-. .")
        time.sleep(timesl)
        print(MORADOCLARO + "- ..- / ..-. ..- .. ... - . / .- .-.. -.-. --- .-.. .. -.-. .... --- / .-.. .- -. -.. .-. . -.-- --..-- / -.-- .- /"
        ".-.. --- / .-. . -.-. ..- . .-. -.. .- ... / .- .... --- .-. .- ..--..")
        time.sleep(timesl)
        print(ROJOCLARO + "THAT'S LIE" + GRIS + " I wasn't an alcoholic! it's just that...")
        time.sleep(timesl)
        print(GRIS + "i'm need your help")
        time.sleep(timesl)
        print(MORADOSCURO + "-. --- / - . / -- .. . -. - .- ... / .- / - .. / -- .. ... -- ---")
        time.sleep(timesl)
        print(MORADOSCURO + "Do you not need my help")
        time.sleep(timesl)
        print(GRIS + "but...")
        time.sleep(timesl)
        print(ROJOSCURO + "SHUT UP, " + MORADOCLARO + "do you not " + ROJOCLARO + "-. . . -.. / -- .. / .- -.-- ..- -.. .-")
        time.sleep(timesl)
        print(GRIS + "sorry...")
        print(NEGRO + "Cerrando modo debug...")

DebugMode()