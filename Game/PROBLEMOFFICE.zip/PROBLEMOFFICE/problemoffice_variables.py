import os
import re
import cowsay
import time
import sys
import random
from colorama import Fore, Back, Style, init

timesl = 1
timesl2 = 0.3
timesl3 = 2

end1 = False
end2 = False
end3 = False 
allends = False
debugMode = False

LIMA = Fore.LIGHTGREEN_EX
GRIS = Fore.LIGHTBLACK_EX
MORADOSCURO = Fore.MAGENTA
AZULOSCURO = Fore.BLUE
AZULCLARO = Fore.LIGHTBLUE_EX
CYANOSCURO = Fore.CYAN
CYANCLARO = Fore.LIGHTCYAN_EX
AMARILLOSCURO = Fore.LIGHTYELLOW_EX
AMARILLOCLARO = Fore.YELLOW
ROJOSCURO = Fore.RED
ROJOCLARO = Fore.LIGHTRED_EX
RESET = Fore.RESET
VERDE = Fore.GREEN
MORADOCLARO = Fore.LIGHTMAGENTA_EX
NEGRO = Fore.BLACK