from core.problemoffice_variables import *
from game.problemoffice_ends import endgame_bad, endgame_good, endgame_real
from game.problemoffice_endsSecrets import gameend_real1, DebugMode
init(autoreset=True)
def ADMINMOMENT():
    nowhile = False
    global end1, end2, end3
    global allends
    global debugMode
    global Name
    if end1 == True and end2 == True and end3 == True:
        allends = True
    while nowhile == False:
        List = ("📲 Calculate 📲  ℹ Information ℹ  👨‍💼 workers 👩‍💼  ❗ Errors ❗  🎲 Random Number 🎲 🧾 facturation 🧾 🕛 Time 🕛  🔴 Exit 🔴")
        ListName = ("Juan: Producction Pancho: Assistant Andi: Developer Daniel: Analyst Andres: Designer Felipe: Tester Jorge: Supervisor\n" ## EMPLEADOS
                    "Jose: Coordinator Luis: Representative Manuel: Director Miguel: Vice President Pedro: President Ramon: CEO Roberto: CTO Sergio: CIO")
        print(RESET + "¿que es lo que necesitas Manager?"
              + GRIS + "(if you don't remember, type 'list')")
        answer = input(command)
        if (answer == "List" or answer == "list"): ## LISTA DE COMANDOS
            print("Ok, This is the List Code")
            time.sleep(timesl)
            print(CYANCLARO + List)
            time.sleep(timesl)
        elif (answer == "facturation" or answer == "Facturation"):
            global number
            print(GRIS + "(numero que quieras factorizar)")
            number = input(command)
            Facturations(number)
        elif (answer == "3336560110317Room:destruction"): ## FINAL REAL 2
            gameend_real1()
        elif (answer == "Calculate" or answer == "calculate"): ## CALCULADORA
            x = int(input(AZUL + "el primer numero es: "))
            o = input(LIMA + "el operador(+, -, *, /, **, %) es: ")
            y = int(input(AZUL + "y el segundo numero es: "))
            print(RESET + "total es: " + LIMA + str(float(eval(f"{x} {o} {y}"))))
            time.sleep(timesl)
        elif (answer == "Information" or answer == "information"): ## INFORMACION DEL CLIENTE
            print(AZUL + "User: Daniel Naranjo\n"
            "Level to the Job: Manager\n"
            "Date of Birth: 2/2/2012\n"
            "Age: 29\n ID: I492915599\n"
            "Dispositive: DESKTOP-9OND5CF\n")
            time.sleep(timesl)
        elif (answer == "Workers" or answer == "workers"): ## TRABAJADORES
            print("Workers List")
            print(CYANCLARO + ListName)
            time.sleep(timesl)
        elif (answer == "Errors" or answer == "errors"): ## ERRORES (FINALES)
            answer2 = input(ROJOSCURO + "ERROR_1:see more [Y/N] ")
            if (answer2 == "Y" or answer2 == "y"):
                print(ROJOSCURO +"ERROR_1:error ocurre por que una suma esta incorrecta")
                z = input(RESET +"fue 240563 * 20495 + 2012 ")
                if z == "1031656017/20120202/29/492915599": ## FINAL SECRETO
                    print(MORADOSCURO + "--.- ..- . / . ... / . ... - .- / ... . -. ... .- -.-. .. --- -. / -.. . / -- .. . -.. --- ..--..\n -. --- / .--. ..- . -.. --- / -.-. .-. . . .-. -- . .-.. --- --..-- / . ... / .. -- .--. --- ... .. -... .-.. . / --.- ..- . / ... . .- / .-. . .- .-..\n ...---...")
                    print(ROJOCLARO +"https://www.youtube.com/watch?v=olRIGRomCMM&pp=0gcJCU8LAYcqIYzv")
                    cowsay.cow(RESET +"ERROR_1:solving...")
                    time.sleep(timesl2)
                    print(LIMA +"ERROR_1:solved")
                    time.sleep(timesl2)
                    print(MORADOSCURO +"secret end")
                    print("1031")
                    time.sleep(timesl)
                    end3 = True
                    continue
                elif z == "492915599": ## FINAL BUENO
                    end1 = True
                    for i in range(1, 10):
                        print(AMARILLOCLARO + "ERROR_1:solving...")
                        time.sleep(timesl2)
                    print(LIMA + "ERROR Solutioned")
                    endgame_good()
                else: ## FINAL MALO
                    end2 = True
                    print(ROJOSCURO + "Incorrect\n Close SECCTION")
                    endgame_bad()
        elif (answer == "$terminal:real./02978" and allends == True): ## FINAL REAL
            password2 = input(MORADOSCURO +"Password: ")
            if password2 == "1031656017Root":
                pas = input(MORADOSCURO + f"key the pass:\n {command}")
                if pas == "access Root":
                    print(AMARILLOSCURO + "loading...")
                    time.sleep(timesl3)
                    print(MORADOCLARO +"Bienvenido a la terminal real, Manager")
                    time.sleep(timesl)
                    print(ROJOSCURO + "Ejecuta este comando para conocer la verdad")
                    q = input(RESET + f"[Y/N] \n {command} ")
                    if q == "Y" or q == "y":
                        print(RESET + "loading...")
                        time.sleep(timesl3)
                        print(MORADOCLARO + "ProblemOffice no era una oficina")
                        time.sleep(timesl)
                        print(MORADOCLARO + "Era una simulación para encontrar al nuevo administrador del sistema")
                        time.sleep(timesl)
                        print(MORADOCLARO + "Cada final era un registro de una prueba distinta")
                        time.sleep(timesl)
                        print(MORADOCLARO + "Solo quien reuniera todos los registros podía acceder al archivo principal.")
                        time.sleep(timesl)
                        print(MORADOCLARO + "y lo lograste, afortunadamente\n nada realmente existio,\n todo fue una simulacion para encontrar al nuevo administrador del sistema")
                        time.sleep(timesl)
                        print(MORADOCLARO + "y fuiste tu que lograste resolver todos los problemas y encontrar la verdad")
                        time.sleep(timesl)
                        print(ROJOSCURO + "cerrando terminal y eliminar todo la terminal de tu computadora, para que nadie pueda acceder a la terminal real")
                        time.sleep(timesl)
                        endgame_real()
                    else:
                        print(ROJOCLARO + "De acuerdo, adios")
                        nombre()
        elif (answer == "Exit" or answer == "exit"): ## SALIR
            print(f"good bye" + Name["[Gerente]"])
            answer3 = input(ROJOCLARO + "desea volver a iniciar sesion o no? [Y/N] ")
            if (answer3 == "N" or answer3 == "n"):
                nowhile = True
                return nombre()
            if (answer3 == "Y" or answer3 == "y"):
                RESET
                PasswordMoment()
        elif (answer == "Random Number" or answer == "random"): ## NUMERO RANDOM
            os.system("color 09")
            a = int(input("Random Number is: "))
            if a == random.randint(1, 10):
                print(LIMA + "You are lucky")
                time.sleep(timesl)
            else:
                print(ROJOSCURO + "You are not lucky")
                time.sleep(timesl)
        elif (answer == "Time" or answer == "time"): ## TIMEPO REAL
            print(CYANOSCURO +"Fecha y hora actual:")
            print(CYANCLARO + time.ctime())
            time.sleep(timesl)
        elif (answer == "allends"): ## ACTIVAR TODOS LOS FINALES
            allends = True
            debugMode = True
            print(LIMA + "Otra vez" + MORADOSCURO + " -.-. --- .-. .-. . -.-. -")
            time.sleep(timesl)
        elif (answer == "debugMode" and debugMode == True): ## DEBUGMODE (FINAL)
            print("Entrando al modo debug...")
            time.sleep(timesl3)
            DebugMode()
        else: ## ERROR AL ESCRIBIR O COMANDO DESCONOCIDO
            print(ROJOCLARO +"Comando desconocido: otra vez")
            time.sleep(timesl)       
def UNKOWNMOMENT(): ## MOMENTO USUARIO DESCONOCIDO
    user = sys.argv[1] if len(sys.argv) > 1 else "Unknown"
    print("Hello", user)
    time.sleep(timesl)
    print("Sorry but you are not recognized as a user, please contact the administrator")
    time.sleep(timesl)
    print("If you are the administrator, please contact the developer")
    time.sleep(timesl)
    print(ROJOSCURO + "System proteccion: ACCES_DENIED FOR", user, "User not recognized")
    time.sleep(timesl)
    return nombre()
def PasswordMoment(): ## CONTRASEÑAS
    global end1
    global end2
    global end3
    user = sys.argv[1] if len(sys.argv) > 1 else "Unknown"
    while True:
        print("email please")
        Email = input(AMARILLOCLARO + "Your email is: ")
        if Email == "daniel.naranjo@company.com":
            print(MORADOCLARO + "Email is the Daniel")
            time.sleep(timesl)
            print(MORADOSCURO + "$terminal:real./02978 ")
            print(LIMA + (f"{end1} {end2} {end3}"))
            time.sleep(timesl)
            print(MORADOCLARO + "do you was to need")
            time.sleep(timesl)
            print(MORADOCLARO + "the real terminal")
            time.sleep(timesl)
        elif Email == "andresesgay@gmail.com":
            print("jajaja pobre gay 😂😂")
            correoandres()
        elif re.search(r"^[\w\.-]+@[\w\.-]+\.\w+$", Email):
            print(LIMA +"Email is correct")
            time.sleep(timesl)
        else:
            print(ROJOSCURO + "Email is incorrect, try again")
            time.sleep(timesl)
            return
        print("Password Please")
        Password = input(AMARILLOCLARO + "Your password is: ")
        if Password == "" or Password == " ":
            print(ROJOSCURO + "ACCESS_DENIED: try again")
            time.sleep(timesl)
        elif Password == "2/2/2012" or Password == "2/2012" or Password == "" or Password == "2 de febrero de 2012":
            print(VERDE + "ACCESS_ALLOWED, User: Daniel Naranjo, Manager")
            time.sleep(timesl)
            os.system("cls")
            print(introM)
            ADMINMOMENT()
        elif Password == "+500":
            print("gracias por ser detallista")
            time.sleep(timesl)
            print("'allends' para admin")
            ADMINMOMENT()
        else:
            print("ACCESS_ALLOWED, User: ", user)
            t = input(CYANCLARO + "menseje [Y/N]\n" + command)
            if t == "Y":
                UNKOWNMOMENT()
            else:
                print("Ok")
                time.sleep(timesl)
                print(ROJOSCURO + "Close Count")
                return nombre()
def nombre(): ## PRESENTACION
    global Name
    Name = {"[Nombre]" : "Daniel Naranjo",
            "[Gerente]" : "gerente"}
    for po in range(1, 5):
        print(AMARILLOCLARO + "prendiendo...")
        time.sleep(timesl)
    print(AMARILLOSCURO +"💽 equipo prendido 💽")
    time.sleep(timesl3)
    print("📀 Bienvenido Usuario a disquet 1998 📀")
    time.sleep(timesl)
    print(AMARILLOCLARO + "[!]notificaciones: 1[!]", end="\n")
    time.sleep(timesl)
    print("📧 entrando a email 📧")
    time.sleep(timesl)
    print("📧 logeado de email: Daniel")
    print(Fore.CYAN + '📨 Mensajes: 1 de "empleado245"')
    f = input(CYANCLARO + "📧 ¿abrir? [Y/N] ")
    if (f == "Y" or f == "y"):
        print(RESET + "✉ Hola", Name["[Gerente]"])
        time.sleep(timesl)
        print("A surgido algo para resolver, un problema muy importante")
        time.sleep(timesl)
        Inicio = input(CYANCLARO + "¿estas seguro que puedes hacerlo? [Y/N] " )
        if (Inicio == "N" or Inicio == "n"):
            print(ROJOCLARO + "No pasa nada, vuelve si estas seguro")
            time.sleep(timesl)
            print(ROJOSCURO +"❌ TERMINAL: ACCESO_DENEGADO PARA " + LIMA + Name["[Gerente]"] + " ❌")
            time.sleep(timesl)
        elif (Inicio == "Y" or Inicio == "y"):
            print(RESET + "Por si acaso, usa este numero de emergencia por si sucede algo" + LIMA + " 492915599")
            time.sleep(timesl)
            print(AMARILLOCLARO + "logeando en la terminal_Job")
            time.sleep(timesl)
            print(VERDE + "✔TERMINAL: ACCESO_AUTORIZADO PARA: " + LIMA + Name["[Gerente]"] + " ✔")
            time.sleep(timesl)
            print("Bienvenido a la terminal " + VERDE + Name["[Nombre]"])
            time.sleep(timesl)
            PasswordMoment()
    else:
        print("📩 mensaje ignorado 📩")
        return nombre()
##--- Funciones ---##
def Facturations(n):
    n = number  
    print(RESET + "Este es el valor de facturaciones de organizacion\n"
          "del equipo de trabajadores de primeros pisos\n")
    print(CYANCLARO + "¿deseas aceptar esta afirmación?")
    Aff = input(f"{command} [Y/N]")
    if Aff == "Y" or Aff == "y":
        print(AMARILLOCLARO + "enviado...")
    elif Aff == "N" or Aff == "n":
        print(ROJOCLARO + "no enviado...")
    else:
        print("!error!: volver a intentarlo")
        return Facturations()
def correoandres():
    print("✉ Yo soy Andrés y me considero gay")
    for i in range(1, 20):
        print("Andrés es gay 🏳‍🌈 😂😂😂😂😂😂😂")
        time.sleep(timesl2)
    print("pobrecito")
    UNKOWNMOMENT()