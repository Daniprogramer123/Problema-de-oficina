from core.problemoffice_variables import *
def endgame_good():
    os.system("color 0A")
    print("Lo lograstes! felcicitaciones, has solucionado el problema")
    time.sleep(timesl)
    print("Gracias por jugar problemoffice.py\n nos vemos")
    time.sleep(timesl)
    for p in range(1, 20):
        print(GRIS + "Cerrando...")
        time.sleep(timesl2)
    print(ROJOSCURO + "Cerrado")
    cowsay.cow("Game Created by Daniel Naranjo")
    print("65601")
    nowhile = True
def endgame_bad():
    print("Lo siento, no has podido solucionar el problema")
    time.sleep(timesl)
    print(f"Gracias por jugar {introT}\n nos vemos")
    time.sleep(timesl)
    for p in range(1, 20):
        print("cerrando...")
        time.sleep(timesl)
    print("Cerrado")
    time.sleep(timesl3)
    print(ROJOSCURO + "Game Over")
    time.sleep(timesl)
    cowsay.cow("Game Created by Daniel Naranjo")
    print("7Root")
    nowhile = True
    from problemoffice_introAdminmoment import PasswordMoment
    return PasswordMoment()
def endgame_real():
    user = sys.argv[1] if len(sys.argv) > 1 else "User game"
    os.system("color 0A")
    print("encontraste la verdad de problemoffice.py", user)
    time.sleep(timesl)
    print("Gracias por jugar problemoffice.py\n nos vemos")
    print("Una proxima vez")
    time.sleep(timesl)
    for p in range(1, 20):
        os.system("color 0E")
        print("Cerrando")
        time.sleep(timesl2)
    os.system("color 07")
    print("Cerrado") or print("Closed")
    cowsay.cow("Juego creado por: Daniel Naranjo")
    print("gracias por jugar")
    time.sleep(5)
    print(user)
    print("cantidad de lineas creadas: +500")
    nowhile = True