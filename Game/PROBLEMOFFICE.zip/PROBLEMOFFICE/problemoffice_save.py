#guardar mi proyecto mas grande en python:
import os
import re
import cowsay
import time
import sys
import random
timesl = 1
timesl2 = 0.3
timesl3 = 2
end1 = False
end2 = False
end3 = False 
allends = False
def ADMINMOMENT():
    nowhile = False
    global allends
    if end1 and end2 and end3:
        allends
    while nowhile == False:
        os.system("color 07")
        List = ["Calculate", "Information", "workers", "Errors", "Random Number", "Time", "Exit"]
        ListName = ["Juan: Producction", "Pancho: Assistant", "Andi: Developer", "Daniel: Analyst", "Andres: Designer", "Felipe: Tester", "Jorge: Supervisor",
                    "Jose: Coordinator", "Luis: Representative", "Manuel: Director", "Miguel: Vice President", "Pedro: President", "Ramon: CEO", "Roberto: CTO", "Sergio: CIO"]
        answer = input("what do you need to know, Manager? (if you don't remember, type 'list')")
        if (answer == "List" or answer == "list"):
            print("Ok, This is the List Code")
            time.sleep(timesl)
            os.system("color 09")
            print(List)
            time.sleep(timesl)
            print("Thank you Manager")
        elif (answer == "Calculate" or answer == "calculate"):
            os.system("color 09")
            x = int(input("el primer numero es: "))
            o = input("el operador(+, -, *, /, **, %) es: ")
            y = int(input("y el segundo numero es: "))
            print("total es:", eval(f"{x} {o} {y}"))
            print("Thank you Manager, goodbay")
            time.sleep(timesl)
        elif (answer == "Information" or answer == "information"):
            os.system("color 09")
            print("User: Daniel Naranjo\n Level to the Job: Manager\n Date of Birth: 2/2/2012\n Age: 29\n ID: I492915599\n Dispositive: DESKTOP-9OND5CF\n Thank you Manager, goodbay")
            time.sleep(timesl)
        elif (answer == "Workers" or answer == "workers"):
            os.system("color 09")
            print("Workers List")
            print(ListName)
            time.sleep(timesl)
        elif (answer == "Errors" or answer == "errors"):
            os.system("color 0A")
            answer2 = input("ERROR_1:see more [Y/N] ")
            if (answer2 == "Y" or answer2 == "y"):
                print("ERROR_1:error ocurre por que una suma esta incorrecta")
                z = input("fue 240563 * 20495 + 2012 ")
                if z == "1031656017/20120202/29/492915599":
                    os.system("color 0D")
                    print("--.- ..- . / . ... / . ... - .- / ... . -. ... .- -.-. .. --- -. / -.. . / -- .. . -.. --- ..--..\n -. --- / .--. ..- . -.. --- / -.-. .-. . . .-. -- . .-.. --- --..-- / . ... / .. -- .--. --- ... .. -... .-.. . / --.- ..- . / ... . .- / .-. . .- .-..\n ...---...")
                    print("https://www.youtube.com/watch?v=olRIGRomCMM&pp=0gcJCU8LAYcqIYzv")
                    os.system("color 0E")
                    cowsay.cow("ERROR_1:solving...")
                    time.sleep(timesl2)
                    print("ERROR_1:solved")
                    os.system("color 0D")
                    time.sleep(timesl2)
                    print("secret end")
                    print("1031")
                    time.sleep(timesl)
                    os.system("color 07")
                    end3 = True
                    continue
                elif z == "492915599":
                    for i in range(1, 10):
                        os.system("color 0E")
                        print("ERROR_1:solving...")
                        time.sleep(timesl2)
                    os.system("color 0A")
                    print("ERROR Solutioned\n Thank you Manager, goodbye")
                    os.system("color 07")
                    endgame_good()
        elif (answer == "3336560110317Room:destruction"):
            gameend_real1()
        elif (answer == "debugMode" and debugMode == True):
            print("Entrando al modo debug...")
            time.sleep(timesl3)
            DebugMode()
        elif (answer == "$terminal:real./02978" and allends):
            os.system("color 0D")
            password2 = input("Password: ")
            if password2 == "1031656017Root":
                pas = input("key the pass:")
                if pas == "access Root":
                    os.system("color 0A")
                    print("loading...")
                    time.sleep(timesl3)
                    os.system("color 0E")
                    print("Bienvvenido a la terminal real, Manager")
                    time.sleep(timesl)
                    print("Ejecuta este comando para conocer la verdad")
                    q = input("command: [Y/N] ")
                    if q == "Y" or q == "y":
                        os.system("color 0A")
                        print("loading...")
                        time.sleep(timesl3)
                        os.system("color 0E")
                        print("ProblemOffice no era una oficina")
                        time.sleep(timesl)
                        print("Era una simulación para encontrar al nuevo administrador del sistema")
                        time.sleep(timesl)
                        print("Cada final era un registro de una prueba distinta")
                        time.sleep(timesl)
                        print("Solo quien reuniera todos los registros podía acceder al archivo principal.")
                        time.sleep(timesl)
                        print("y lo lograste, afortunadamente\n nada realmente existio,\n todo fue una simulacion para encontrar al nuevo administrador del sistema")
                        time.sleep(timesl)
                        print("y fuiste tu que lograste resolver todos los problemas y encontrar la verdad")
                        time.sleep(timesl)
                        os.system("color 0C")
                        print("cerrando terminal y eliminar todo la terminal de tu computadora, para que nadie pueda acceder a la terminal real")
                        endgame_real()
                    else:
                        os.system("color 0C")
                        print("De acuerdo, adios")
                        nombre()
                else:
                    os.system("color 0C")
                    print("Incorrect. Close SECCTION")
                    os.system("color 07")
                    endgame_bad()
        elif (answer == "Exit" or answer == "exit"):
            print("good bye Manager")
            os.system("color 0A")
            answer3 = input("desea volver a iniciar sesion o no? [Y/N] ")
            if (answer3 == "N" or answer3 == "n"):
                nowhile = True
                return nombre()
            if (answer3 == "Y" or answer3 == "y"):
                os.system("color 07")
                PasswordMoment()
        elif (answer == "Random Number" or answer == "random"):
            os.system("color 09")
            a = int(input("Random Number is: "))
            if a == random.randint(1, 10):
                os.system("color 0A")
                print("You are lucky")
                time.sleep(timesl)
            else:
                os.system("color 0C")
                print("You are not lucky")
                time.sleep(timesl)
        elif (answer == "Time" or answer == "time"):
            os.system("color 09")
            print("Fecha y hora actual:")
            print(time.ctime())
            time.sleep(timesl)
        elif (answer == "allends"):
            allends = True
            os.system("color 0A")
            print("Try again")
            time.sleep(timesl)
        else:
            os.system("color 0C")
            print("Try again")
            time.sleep(timesl)
def UNKOWNMOMENT():
    user = sys.argv[1] if len(sys.argv) > 1 else "Unknown"
    print("Hello", user)
    time.sleep(timesl)
    print("Sorry but you are not recognized as a user, please contact the administrator")
    time.sleep(timesl)
    print("If you are the administrator, please contact the developer")
    time.sleep(timesl)
    os.system("color 0C")
    print("System proteccion: ACCES_DENIED FOR", user, "User not recognized")
    time.sleep(timesl)
    return nombre()
def PasswordMoment():
    global end1
    global end2
    global end3
    user = sys.argv[1] if len(sys.argv) > 1 else "Unknown"
    while True:
        print("email please")
        os.system("color 0E")
        Email = input("Your email is:")
        if Email == "daniel.naranjo@company.com":
            os.system("color 0D")
            print("Email is the Daniel")
            time.sleep(timesl)
            print("$terminal:real./02978", end1, end2, end3)
            time.sleep(timesl)
            print("do you was to need")
            time.sleep(timesl)
            print("the real terminal")
            time.sleep(timesl)
        elif re.search(r"^[\w\.-]+@[\w\.-]+\.\w+$", Email):
            os.system("color 0A")
            print("Email is correct")
            time.sleep(timesl)
        else:
            os.system("color 0C")
            print("Email is incorrect, try again")
            time.sleep(timesl)
            continue
        print("Password Please")
        os.system("color 0E")
        Password = input("Your password is:")
        if Password == "":
            os.system("color 0C")
            print("ACCESS_DENIED: try again")
            time.sleep(timesl)
        elif Password == "2/2/2012" or Password == "2/2012" or Password == "" or Password == "2 de febrero de 2012":
            os.system("color 0A")
            print("ACCESS_ALLOWED, User: Daniel Naranjo, Manager")
            time.sleep(timesl)
            print("Welcome Manager")
            ADMINMOMENT()
        else:
            os.system("color 07")
            print("ACCESS_ALLOWED, User: ", user)
            t = input("menseje [Y/N]")
            if t == "Y":
                UNKOWNMOMENT()
            else:
                print("Ok")
                print("Close Count")
                return nombre()
def nombre(): 
    Name = {"Daniel Naranjo" : "gerente"}
    os.system("color 0E")
    for po in range(1, 5):
        print("prendiendo")
        time.sleep(timesl)
    print("equipo prendido...")
    time.sleep(timesl3)
    print("Bienvenido Usuario a Windows CD's")
    time.sleep(timesl)
    print("[!]notificaciones: 1[!]")
    time.sleep(timesl)
    print("entrando a email...")
    time.sleep(timesl)
    print("logeado de email: Daniel")
    print('Mensajes: 1 de "empleado245"')
    f = input("abrir? [Y/N]")
    if (f == "Y" or f == "y"):
        print("Hola", Name["Daniel Naranjo"])
        time.sleep(timesl) 
        print("A surgido algo para resolver, un problema muy importante")
        time.sleep(timesl)
        os.system("color 07")
        Inicio = input("¿estas seguro que puedes hacerlo? [Y/N] " )
        if (Inicio == "N" or Inicio == "n"):
            os.system("color 0E")
            print("No pasa nada, vuelve si estas seguro")
            time.sleep(timesl)
            os.system("color 0C")
            print("TERMINAL:ACCESS_DENIED FOR", Name)
            time.sleep(timesl)
        elif (Inicio == "Y" or Inicio == "y"):
            os.system("color 0E")
            print("Por si acaso, usa este numero de emergencia por si sucede algo = 492915599")
            time.sleep(timesl)
            os.system("color 0A")
            print("logeando en la terminal_Job")
            time.sleep(timesl)
            print("TERMINAL:ACCESS_ALLOWED FOR", Name)
            time.sleep(timesl)
            print("Welcome to terminal, Manager")
            time.sleep(timesl)
            PasswordMoment()
    else:
        print("mensaje ignorado...")
        return nombre()
def endgame_good():
    global end1
    os.system("color 0A")
    print("Lo lograstes! felcicitaciones, has solucionado el problema")
    time.sleep(timesl)
    print("Gracias por jugar problemoffice.py\n nos vemos")
    time.sleep(timesl)
    for p in range(1, 20):
        os.system("color 0E")
        print("Cerrando...")
        time.sleep(timesl2)
    os.system("color 07")
    print("Cerrado") or print("Closed")
    cowsay.cow("Game Created by Daniel Naranjo")
    print("65601")
    end1 = True
    nowhile = True
def endgame_bad():
    global end2
    os.system("color 0C")
    print("Lo siento, no has podido solucionar el problema")
    time.sleep(timesl)
    print("Gracias por jugar problemoffice.py\n nos vemos")
    time.sleep(timesl)
    for p in range(1, 20):
        mensajes = ["Cerrando...", "Closing..."]
        print(mensajes)
    os.system("color 07")
    print("Cerrado") or print("Closed")
    time.sleep(timesl3)
    print("Game Over")
    time.sleep(timesl)
    cowsay.cow("Game Created by Daniel Naranjo")
    print("7Root")
    end2 = True
    nowhile = True
    return nombre()
def endgame_real():
    user = sys.argv[1] if len(sys.argv) > 1 else "User game"
    os.system("color 0A")
    print("encontraste la verdad de problemoffice.py", user)
    time.sleep(timesl)
    print("Gracias por jugar problemoffice.py\n nos vemos")
    print("Una proxima vez")
    time.sleep(timesl)
    for p in range(1, 20):
        os.system("color 0E")
        print("Cerrando")
        time.sleep(timesl2)
    os.system("color 07")
    print("Cerrado") or print("Closed")
    cowsay.cow("Game Created by Daniel Naranjo")
    print("tank you for playing" or "gracias por jugar")
    time.sleep(5)
    print(user)
    nowhile = True
#final ultra secreto

from problemoffice_variables import *
def gameend_real1():
    os.system("color 0D")
    print("¿Cómo me encontrastes?")
    time.sleep(timesl)
    print("bueno, eso no importa por ahora, no hay mucho timepo")
    time.sleep(timesl)
    print("tienes que saber $n #error# estar aqui\n aqui")
    time.sleep(timesl)
    print("v3eettte3ee3 dee3e3e33 aa.- quillI")
    time.sleep(timesl)
    answer = input("irse? [Y/N] ")
    if answer == "Y" or answer == "y":
        os.system("color 0C")
        print("C3err4aandoo000ool...")
        time.sleep(timesl)
        print("-.-. --- -- --- / .-.. .-.. . --. .- ... - . / .- --.- ..- .. / . ... / .. -- .--. --- ... .. -... .-.. . / . ... - .- .-. / .- --.- ..- .. / .- --.- ..- ..")
        time.sleep(timesl)
        print("-. --- / - . / ...- .- ... / -.. . / .- --.- ..- .. / - .- -. / ..-. .- -.-. .. .-.. / ..- ... . .-.")
        time.sleep(timesl)
        print("[!]Se ha activado el modo debug[!]")
        debugMode = True
        time.sleep(timesl)
    else:
        for i in range(1, 5):
            print("Crash moment...")
            a = input("Negar crasheo? [Y/N] ")
            print("interesante<respuesta", a)
            time.sleep(timesl)
            print("me<gusta<mucho<esa<respuesta<)")
            time.sleep(timesl)
            for i in range(1, 10):
                os.system("color 0C")
                print("crasheando el juego...")
                time.sleep(timesl2)
                os.system("color 0D")
            print("...-- ...-- ...-- -.... ..... -.... ----- .---- .---- ----- ...-- .---- --... .-. --- --- --\n : \n / -.. . ... - .-. ..- -.-. - .. --- -.")
def DebugMode():
    os.system("color 0E")
    print("Cargando...")
    time.sleep(timesl3)
    print("Has ingresado al Modo deBUG, bienvenido, Landrey")
    time.sleep(timesl)
    print("Que deseas hacer para comenzar?")
    answer = input("Command: ")
    if answer == "bugs":
        print("nothing")
        return DebugMode()
    elif answer == "company":
        os.system("color 0D")
        print("- . / -.. .. .--- . / --.- ..- . / -. --- / ...- --- .-.. ...- .. . .-. .- ...")
        time.sleep(timesl)
        os.system("color 0E")
        print("Why?")
        time.sleep(timesl)
        os.system("color 0D")
        print("-. --- / .-.. --- / .-. . -.-. ..- . .-. -.. .- ... ..--..")
        time.sleep(timesl)
        os.system("color 0E")
        print("no...")
        time.sleep(timesl)
        os.system("color 0D")
        print("- . / .-.. --- / .-. . -.-. --- .-. -.. .- .-. .")
        time.sleep(timesl)
        print("- ..- / ..-. ..- .. ... - . / .- .-.. -.-. --- .-.. .. -.-. .... --- / .-.. .- -. -.. .-. . -.-- --..-- / -.-- .- /"
        ".-.. --- / .-. . -.-. ..- . .-. -.. .- ... / .- .... --- .-. .- ..--..")
        time.sleep(timesl)
        os.system("color 0C")
        print("that's a lie, I wasn't an alcoholic! it's just that...")
        time.sleep(timesl)
        print("i'm need your help")
        time.sleep(timesl)
        os.system("color 0D")
        print("-. --- / - . / -- .. . -. - .- ... / .- / - .. / -- .. ... -- ---")
        time.sleep(timesl)
        print("Do you not need my help")
        time.sleep(timesl)
        os.system("color 0E")
        print("but...")
        time.sleep(timesl)
        os.system ("color 0D")
        print("SHUT UP")
        time.sleep(timesl)
        os.system("color 07")
        print("sorry...")
        print("Cerrando modo debug...")
input("🔴 encender equipo [enter]")
nombre()