import os
import re
import cowsay
import time
import sys
import random
from colorama import Fore, Back, Style, init
## tiempos de espera
timesl = 1
timesl2 = 0.3
timesl3 = 2
## Finales
end1 = False
end2 = False
end3 = False 
allends = False
debugMode = False
## Colores
LIMA = Fore.LIGHTGREEN_EX
GRIS = Fore.LIGHTBLACK_EX
MORADOSCURO = Fore.MAGENTA
AZUL = Fore.BLUE
CYANOSCURO = Fore.CYAN
CYANCLARO = Fore.LIGHTCYAN_EX
AMARILLOSCURO = Fore.LIGHTYELLOW_EX
AMARILLOCLARO = Fore.YELLOW
ROJOSCURO = Fore.RED
ROJOCLARO = Fore.LIGHTRED_EX
RESET = Fore.RESET
VERDE = Fore.GREEN
MORADOCLARO = Fore.LIGHTMAGENTA_EX
NEGRO = Fore.BLACK
## Textos repetidos
command = "💾 Command: " + LIMA
introT = MORADOCLARO +  " ╔══════════════════════════════════════╗\n ║          PROBLEMOFFICE v2.0          ║\n ╚══════════════════════════════════════╝"
introM = MORADOCLARO +  " ╔══════════════════════════════════════╗\n ║          TERMINAL JOB MANAGER        ║\n ╚══════════════════════════════════════╝"